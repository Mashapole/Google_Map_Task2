package com.example.wemap;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

public class splash_screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);


        ActionBar bar=getSupportActionBar();
        bar.hide();


        Handler h= new Handler();
        h.postDelayed(new Runnable() {
            @Override
            public void run()
            {
                Intent intent= new Intent(splash_screen.this, Login_activity.class);
                startActivity(intent);

            }
        },5000);
    }
}