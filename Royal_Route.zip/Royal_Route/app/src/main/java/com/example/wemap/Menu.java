package com.example.wemap;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

public class Menu extends AppCompatActivity {

    GridView gridView;
    String[] numberInWords = {"GPS","Favourite","Settings","Quit"};
    int[] numberImage = {R.drawable.map,R.drawable.favourite,R.drawable.setting_,R.drawable.exit};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        ActionBar bar=getSupportActionBar();
        bar.setTitle("Menu");

        gridView = findViewById(R.id.gridView);
        MainAdapter mainAdapter = new MainAdapter(Menu.this, numberInWords,numberImage);
        gridView.setAdapter(mainAdapter);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                if(numberInWords[+position].equals("GPS"))
                {
                    Intent intent= new Intent(Menu.this, MapsActivity.class);
                    startActivity(intent);
                }
                else if(numberInWords[+position].equals("Favourite"))
                {
                    Intent intent= new Intent(Menu.this, list_of_activity.class);
                    startActivity(intent);
                }
                else if(numberInWords[+position].equals("Settings"))
                {
                    //Intent intent= new Intent(Menu.this, SettingsActivity.class);
                    //startActivity(intent);
                }
                else
                {
                    System.exit(1);
                }
            }
        });
    }

}