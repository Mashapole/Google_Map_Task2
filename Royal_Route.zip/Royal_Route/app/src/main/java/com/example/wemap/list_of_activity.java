package com.example.wemap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class list_of_activity extends AppCompatActivity {

    public ListView lsv;
    public ArrayAdapter<String> adapter;
    public ArrayList<String> list;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of);

        getSupportActionBar().setTitle("Saved Addresses");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        lsv = findViewById(R.id.list);

        list=new ArrayList<String>();
        adapter= new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, list);
        lsv.setAdapter(adapter);


        DatabaseReference ref= FirebaseDatabase.getInstance().getReference();
        ref.child("list").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot)
            {
                String svd="";

                for(DataSnapshot s: snapshot.getChildren())
                {
                    svd=s.child("address").getValue(String.class);

                    list.add(svd);
                    adapter.notifyDataSetChanged();
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error)
            {

            }
        });
    }
}