package com.example.wemap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class register_activity extends AppCompatActivity {


    public EditText cName, cEmail, cPassword,cLast;
    public String eName, eEmail, ePassword;
    public FirebaseAuth auth;
    Button regRegiser;
    ImageView regLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        ActionBar bar=getSupportActionBar();
        bar.hide();
        auth = FirebaseAuth.getInstance();

        cLast = findViewById(R.id.txtLastName);
        cName = findViewById(R.id.txtFirstname);
        cEmail = findViewById(R.id.txtEmail);
        cPassword = findViewById(R.id.txtPassword);





        regRegiser = findViewById(R.id.btn_register);

        regRegiser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                eName = cName.getText().toString().trim();
                eEmail = cEmail.getText().toString().trim();
                ePassword = cPassword.getText().toString().trim();

                if (eName.isEmpty()) {

                    cName.setError("Enter Name");
                    return;
                }
                if (cLast.getText().toString().isEmpty()) {

                    cName.setError("Enter this");
                    return;
                }
                if (eEmail.isEmpty()) {
                    cEmail.setError("Enter Email");
                    return;
                }
                if (!Patterns.EMAIL_ADDRESS.matcher(eEmail).matches()) {
                    cEmail.setError("Enter valid Email");
                    cEmail.requestFocus();
                    return;
                }

                if (ePassword.isEmpty()) {
                    cPassword.setError("Enter Password");
                    return;
                }
                if (ePassword.length() < 7) {
                    cPassword.setError("PLease make sure password length is greater than 10 character");
                    return;
                }

                if (eName != null || eEmail != null || ePassword != null) {
                    auth.createUserWithEmailAndPassword(eEmail, ePassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                model_user l = new model_user(eName, eEmail, ePassword);
                                FirebaseDatabase.getInstance().getReference("person").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                        .setValue(l).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isComplete()) {
                                            Toast.makeText(register_activity.this, "Registere Well", Toast.LENGTH_SHORT).show();
                                            cName.setText("");
                                            cEmail.setText("");
                                            cPassword.setText("");
                                        } else {
                                            Toast.makeText(register_activity.this, "Something Is Wrong", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                            } else {
                                Toast.makeText(register_activity.this, "Account Is Not Added To Database", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }


            }
        });
        regLogin = findViewById(R.id.imgLogin);
        regLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(register_activity.this, Login_activity.class);
                startActivity(intent);
            }
        });

    }
}