package com.example.wemap;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MapsActivity extends FragmentActivity implements
    OnMapReadyCallback,
    GoogleApiClient.ConnectionCallbacks,
    GoogleApiClient.OnConnectionFailedListener,
    LocationListener{


        private GoogleMap getMap;
        private Button viewMenu;
        private BottomSheetDialog getMenu;
        private GoogleApiClient cltApi;
        private LocationRequest regPosition;
        private Location localLocation;
        private Marker markPosition;
        private static final int REQUEST_LOCATION_CODE = 200;
        private int PROXIMITY_RADIUS = 10000;
        private double Clatitude,Clongitude;
        private StringBuilder landmarks;
        private String school;
        private String suggestedList;
        private Button butSchol,butRestaura,butAtm,butShopping,butHospital;
        private ImageView search,refresh;
        private EditText placeName;
        private String pName;
        private Dialog dial;
        private String pass;
        private double lat1,lng2;
        public String addresssssss;
        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);


            getMenu= new BottomSheetDialog(MapsActivity.this);
            getMenu.setContentView(R.layout.viewlandmarks);
            getMenu.setCancelable(true);

            viewMenu=(Button)findViewById(R.id.buMenu);

            viewMenu.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view) {
                    getMenu.show();
                }
            });


            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            {
                LocationPermission();

            }

            refresh=(ImageView) findViewById(R.id.imgfreshn);
            refresh.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    getMap.clear();
                    LatLng latLng = new LatLng(Clatitude , Clongitude);
                    MarkerOptions mrkOption = new MarkerOptions();
                    mrkOption.position(latLng);
                    mrkOption.title("Current Location");
                    mrkOption.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
                    markPosition = getMap.addMarker(mrkOption);
                    getMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                    getMap.animateCamera(CameraUpdateFactory.zoomBy(4));

                }
            });

            placeName=findViewById(R.id.edt_searchPlace);
            Places.initialize(getApplicationContext(), "AIzaSyBbnyQ2xN4wWRC3u3Dk_dBD8qg3n424xMg");

            placeName.setFocusable(false);
            placeName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    //
                    List<Place.Field> fieldList= Arrays.asList(Place.Field.ADDRESS,
                            Place.Field.LAT_LNG, Place.Field.NAME);

                    Intent intent= new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fieldList)
                            .build(MapsActivity.this);

                    startActivityForResult(intent,100);


                }
            });


            search=(ImageView) findViewById(R.id.imgSearch);
            search.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {

                    pName= placeName.getText().toString();

                    if(pName.equals(""))
                    {
                        placeName.setError("required");
                    }
                    else

                    {
                        List<Address> listArray;

                        Geocoder coder = new Geocoder(MapsActivity.this);

                        try {
                            listArray = coder.getFromLocationName(pName, 2);

                            if(listArray != null)
                            {
                                for(int i = 0;i<listArray.size();i++)
                                {
                                    LatLng ln = new LatLng(listArray.get(i).getLatitude() , listArray.get(i).getLongitude());
                                    MarkerOptions getMark = new MarkerOptions();
                                    getMark.position(ln);
                                    getMark.title(pName);
                                    getMap.addMarker(getMark);
                                    getMap.moveCamera(CameraUpdateFactory.newLatLng(ln));
                                    getMap.animateCamera(CameraUpdateFactory.zoomTo(13));
                                }
                            }
                        }
                        catch (IOException e)
                        {
                            e.printStackTrace();
                        }
                        placeName.setText("");

                    }

                }
            });

            butHospital=getMenu.findViewById(R.id.bHospital);
            butHospital.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view) {
                    getMap.clear();
                    getMenu.cancel();
                    Object dataTransfer[] = new Object[2];
                    near_file sugg = new near_file();


                    school= "hospital";
                    suggestedList = SuggestedLandMarks(Clatitude, Clongitude, school);
                    dataTransfer[0] = getMap;
                    dataTransfer[1] = suggestedList;

                    sugg.execute(dataTransfer);
                }
            });

            butShopping=getMenu.findViewById(R.id.bShopping);
            butShopping.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view)
                {
                    getMap.clear();
                    getMenu.cancel();
                    Object dataTransfer[] = new Object[2];
                    near_file sugg = new near_file();


                    school= "shopping";
                    suggestedList = SuggestedLandMarks(Clatitude, Clongitude, school);
                    dataTransfer[0] = getMap;
                    dataTransfer[1] = suggestedList;

                    sugg.execute(dataTransfer);
                }
            });

            butRestaura=getMenu.findViewById(R.id.bRestaurant);
            butRestaura.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view)
                {
                    getMap.clear();
                    getMenu.cancel();
                    Object dataTransfer[] = new Object[2];
                    near_file sugg = new near_file();


                    school= "restaurant";
                    suggestedList = SuggestedLandMarks(Clatitude, Clongitude, school);
                    dataTransfer[0] = getMap;
                    dataTransfer[1] = suggestedList;

                    sugg.execute(dataTransfer);
                }
            });


            butAtm=getMenu.findViewById(R.id.bAtm);

            butAtm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view)
                {
                    getMap.clear();
                    getMenu.cancel();
                    Object dataTransfer[] = new Object[2];
                    near_file sugg = new near_file();


                    school= "atm";
                    suggestedList = SuggestedLandMarks(Clatitude, Clongitude, school);
                    dataTransfer[0] = getMap;
                    dataTransfer[1] = suggestedList;

                    sugg.execute(dataTransfer);
                }
            });
            butSchol=getMenu.findViewById(R.id.bSchool);
            butSchol.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {

                    getMap.clear();
                    getMenu.cancel();
                    Object dataTransfer[] = new Object[2];
                    near_file sugg = new near_file();


                    school= "school";
                    suggestedList = SuggestedLandMarks(Clatitude, Clongitude, school);
                    dataTransfer[0] = getMap;
                    dataTransfer[1] = suggestedList;

                    sugg.execute(dataTransfer);

                }
            });
        }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==100 && resultCode==RESULT_OK)
        {
            Place place= Autocomplete.getPlaceFromIntent(data);

            placeName.setText(place.getAddress());
        }
        else if(resultCode== AutocompleteActivity.RESULT_ERROR)
        {
            Status sta=Autocomplete.getStatusFromIntent(data);
            Toast.makeText(MapsActivity.this, ""+sta.getStatusMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_LOCATION_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                        if (cltApi == null)
                        {
                            startBuilding();
                        }
                        getMap.setMyLocationEnabled(true);
                    }
                } else {
                    Toast.makeText(this, "The Permission Denied", Toast.LENGTH_LONG).show();
                }
        }
    }


    @Override
    public void onMapReady(GoogleMap googleMap)
    {
        getMap = googleMap;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            startBuilding();
            getMap.setMyLocationEnabled(true);
        }
        getMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);


        getMap.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(@NonNull LatLng lng)
            {

                try
                {

                    AlertDialog.Builder builder= new AlertDialog.Builder(MapsActivity.this);
                    builder.setTitle("Preference");
                    builder.setCancelable(true);
                    CharSequence[] charSequence={"Place Details","View Route","Add Favorite","Exit"};
                    builder.setItems(charSequence, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            if(which==0)
                            {
                                try
                                {
                                    Geocoder coder= new Geocoder(MapsActivity.this, Locale.getDefault());
                                    List<Address> addressList=null;


                                    addressList=coder.getFromLocation(lng.latitude, lng.longitude,1);

                                    googleMap.clear();
                                    LatLng lat_lng= new LatLng(lng.latitude, lng.longitude);
                                    MarkerOptions marker= new MarkerOptions();
                                    marker.position(lat_lng);
                                    googleMap.addMarker(marker);
                                    googleMap.moveCamera(CameraUpdateFactory.newLatLng(lat_lng));
                                    googleMap.animateCamera(CameraUpdateFactory.zoomTo(11));

                                }
                                catch (IOException e)
                                {
                                    e.getMessage();
                                }

                                return;
                            }
                            else if (which==1)
                            {
                                Geocoder onLong= new Geocoder(MapsActivity.this, Locale.getDefault());
                                List<Address> longMap=null;
                                try
                                {
                                    longMap=onLong.getFromLocation(lng.latitude, lng.longitude,1);
                                }
                                catch (IOException exception)
                                {
                                    exception.printStackTrace();
                                }


                                Object dataTransfer[] = new Object[2];
                                MarkerOptions mark = new MarkerOptions();

                                if (longMap != null) {
                                    Address theAddress = longMap.get(0);


                                    if (theAddress.hasLatitude() && theAddress.hasLongitude()) {

                                        googleMap.clear();
                                        lat1 = theAddress.getLatitude();
                                        lng2 = theAddress.getLongitude();

                                        LatLng latiAndLong = new LatLng(lat1, lng2);

                                        dataTransfer = new Object[3];
                                        pass = map();
                                        route_file direct = new route_file();
                                        dataTransfer[0] = googleMap;
                                        dataTransfer[1] = pass;
                                        dataTransfer[2] = new LatLng(lat1, lng2);

                                        direct.execute(dataTransfer);

                                        mark.position(latiAndLong);
                                        googleMap.addMarker(mark);
                                        googleMap.animateCamera(CameraUpdateFactory.newLatLng(latiAndLong));
                                        googleMap.animateCamera(CameraUpdateFactory.zoomTo(12));
                                        dialog.cancel();

                                    }
                                }


                                return;
                            }
                            else if (which==2) {
                                try {

                                    Geocoder add = new Geocoder(MapsActivity.this, Locale.getDefault());
                                    List<Address> lst = null;


                                    lst = add.getFromLocation(lng.latitude, lng.longitude, 1);
                                    Address myAddress = lst.get(0);

                                    addresssssss = myAddress.getFeatureName();


                                } catch (IOException e) {
                                    e.printStackTrace();
                                }


                                if (addresssssss == "" || addresssssss == null) {
                                    Toast.makeText(MapsActivity.this, "No Place", Toast.LENGTH_SHORT).show();
                                } else {

                                   list p = new list(addresssssss);
                                    FirebaseDatabase.getInstance().getReference("list").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).push()
                                            .setValue(p).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful())
                                            {
                                                Toast.makeText(MapsActivity.this, "Place Is Store To Database", Toast.LENGTH_SHORT).show();
                                            }
                                            else
                                                {
                                                Toast.makeText(MapsActivity.this, "Not Saved", Toast.LENGTH_SHORT).show();

                                            }


                                        }
                                    });
                                    return;
                                }
                            }
                            else
                            {

                                AlertDialog.Builder b= new AlertDialog.Builder(MapsActivity.this);
                                b.setTitle("Are you sure you want to leave?");
                                b.setCancelable(true);
                                b.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which)
                                    {
                                     System.exit(1);
                                    }
                                });
                                b.setPositiveButton("No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which)
                                    {
                                     dialog.cancel();
                                    }
                                });

                                b.show();
                                return;
                            }
                        }
                    });
                    builder.show();

                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }


            }
        });

        getMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(@NonNull Marker marker)
            {

                Geocoder geocoder= new Geocoder(MapsActivity.this, Locale.getDefault());
                try
                {

                    dial= new Dialog(MapsActivity.this);
                    dial.setCancelable(true);
                    dial.setContentView(R.layout.details);
                    TextView zz1,zz2,zz3,zz4,zz5;

                    dial.show();
                    zz1=dial.findViewById(R.id.name1);
                    zz2=dial.findViewById(R.id.name2);
                    zz3=dial.findViewById(R.id.name3);
                    zz4=dial.findViewById(R.id.name4);
                    zz5=dial.findViewById(R.id.name5);

                    List<Address> lst= null;
                    LatLng latPosition=marker.getPosition();

                    lst=geocoder.getFromLocation(latPosition.latitude,latPosition.longitude,1);

                    String z1,z2,z3,z4,z5;
                    z1=lst.get(0).getAddressLine(0);
                    z2=lst.get(0).getCountryName();
                    z3=lst.get(0).getLocality();
                    z4=lst.get(0).getPostalCode();
                    z5=lst.get(0).getAdminArea();


                    zz1.setText(String.valueOf(z1));
                    zz2.setText(String.valueOf(z2));
                    zz3.setText(String.valueOf(z3));
                    zz4.setText(String.valueOf(z4));
                    zz5.setText(String.valueOf(z5));

                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
                return false;
            }
        });
    }


    protected synchronized void startBuilding() {
        cltApi = new GoogleApiClient.Builder(this).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build();
        cltApi.connect();

    }

    @Override
    public void onLocationChanged(Location local)
    {

        Clatitude = local.getLatitude();
        Clongitude = local.getLongitude();
        localLocation = local;

        if(markPosition != null)
        {
            markPosition.remove();

        }

        LatLng latLng = new LatLng(local.getLatitude() , local.getLongitude());
        MarkerOptions mrkOption = new MarkerOptions();
        mrkOption.position(latLng);
        mrkOption.title("Current Location");
        mrkOption.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));
        markPosition = getMap.addMarker(mrkOption);
        getMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        getMap.animateCamera(CameraUpdateFactory.zoomBy(12));

        if(cltApi != null)
        {
            LocationServices.FusedLocationApi.removeLocationUpdates(cltApi,MapsActivity.this);
        }
    }


    private String SuggestedLandMarks(double locationlatitude , double locationLongitude , String landmark)
    {

        StringBuilder landmarks = new StringBuilder("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
        landmarks.append("location="+locationlatitude+","+locationLongitude);
        landmarks.append("&radius="+PROXIMITY_RADIUS);
        landmarks.append("&type="+landmark);
        landmarks.append("&sensor=true");
        landmarks.append("&key="+"AIzaSyDYxtCVGT9O2e8U3udc2xyDCWPg60kECZI");

        return landmarks.toString();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle)
    {

        regPosition = new LocationRequest();
        regPosition.setInterval(100);
        regPosition.setFastestInterval(1000);
        regPosition.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);


        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION ) == PackageManager.PERMISSION_GRANTED)
        {
            LocationServices.FusedLocationApi.requestLocationUpdates(cltApi, regPosition, MapsActivity.this);
        }
    }


    public boolean LocationPermission()
    {
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)  != PackageManager.PERMISSION_GRANTED )
        {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.ACCESS_FINE_LOCATION))
            {
                ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.ACCESS_FINE_LOCATION },REQUEST_LOCATION_CODE);
            }
            else
            {
                ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.ACCESS_FINE_LOCATION },REQUEST_LOCATION_CODE);
            }
            return false;

        }
        else
            return true;
    }


    @Override
    public void onConnectionSuspended(int i)
    {
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }
    private String map()
    {
        StringBuilder app = new StringBuilder("https://maps.googleapis.com/maps/api/directions/json?");
        app.append("origin="+Clatitude+","+Clongitude);
        app.append("&destination="+lat1+","+lng2);
        app.append("&key="+"AIzaSyBbnyQ2xN4wWRC3u3Dk_dBD8qg3n424xMg");

        return app.toString();
    }
}
