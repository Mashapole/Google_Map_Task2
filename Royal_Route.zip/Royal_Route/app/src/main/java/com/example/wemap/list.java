package com.example.wemap;

public class list {

    public String address;

    public list() {

    }

    public list(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
