package com.example.wemap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login_activity extends AppCompatActivity {

    public EditText  cEmail, cPassword;
    public String  eEmail, ePassword;
    public FirebaseAuth auth;
    Button regLOg;
    ImageView regLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        ActionBar bar=getSupportActionBar();
        bar.hide();
        auth = FirebaseAuth.getInstance();

        cEmail = findViewById(R.id.et_email);
        cPassword = findViewById(R.id.et_password);



        regLOg = findViewById(R.id.btn_login);
        regLOg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                eEmail = cEmail.getText().toString().trim();
                ePassword = cPassword.getText().toString().trim();

                if (eEmail.isEmpty()) {
                    cEmail.setError("Enter Email");
                    return;
                }
                if (!Patterns.EMAIL_ADDRESS.matcher(eEmail).matches()) {
                    cEmail.setError("Enter valid Email");
                    cEmail.requestFocus();
                    return;
                }

                if (ePassword.isEmpty()) {
                    cPassword.setError("Enter Password");
                    return;
                }
                if (ePassword.length() < 7) {
                    cPassword.setError("PLease make sure password length is greater than 10 character");
                    return;
                }

                if (eEmail != null || ePassword != null)
                {
                    auth.signInWithEmailAndPassword(eEmail,ePassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task)
                        {

                            if(task.isSuccessful())
                            {
                                Intent intent= new Intent(Login_activity.this, Menu.class);
                                startActivity(intent);
                            }
                            else
                            {
                                Toast.makeText(Login_activity.this, "Something is wrong", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
        regLogin=findViewById(R.id.goReg);
        regLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(Login_activity.this, register_activity.class);
                startActivity(intent);
            }
        });
    }
}